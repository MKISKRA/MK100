#!/bin/bash
#LD_LIBRARY_PATH=/root/mk100/mk100t/ DISPLAY=:0  /root/mk100/mk100t/MK100T --platform wayland
#pkill MK100T ; LD_LIBRARY_PATH=/root/mk100/mk100t/ /root/mk100/mk100t/MK100T --platform wayland
RESULT=$(uname -r); echo $RESULT
if [[ $RESULT == *5.10.198* ]]; then
echo "RC"
pkill MK100T;AZIMUTH_INI_PATH=/root/mk100/mk100t/settings_azmtqt.ini LD_LIBRARY_PATH=/root/mk100/mk100t/ DISPLAY=:0  /root/mk100/mk100t/MK100T
else
echo "NXP"
pkill MK100T;AZIMUTH_INI_PATH=/root/mk100/mk100t/settings_azmtqt.ini LD_LIBRARY_PATH=/root/mk100/mk100t/ DISPLAY=:0  /root/mk100/mk100t/MK100T --platform wayland
fi
#pkill MK100T;AZIMUTH_INI_PATH=/root/mk100/mk100t/settings_azmtqt.ini LD_LIBRARY_PATH=/root/mk100/mk100t/ DISPLAY=:0  /root/mk100/mk100t/MK100T --platform wayland

