#!/bin/bash
#set -o nounset
#set -o errexit
LOG_FILE=$(date +"%d_%m_%Y")_modemlog.log
LOG_FILE_PATH=/root/mk100/mk100t/logs/$LOG_FILE
exec > >(while read -r line; do printf '%s %s\n' "$(date --rfc-3339=seconds)" "$line" | tee -a $LOG_FILE_PATH; done)
exec 2> >(while read -r line; do printf '%s %s\n' "$(date --rfc-3339=seconds)" "$line" | tee -a $LOG_FILE_PATH; done >&2)

echo "modem log ver: 1.1RC"

while :; do mmcli -m any; mmcli -m any --command=AT+CSQ; sleep 1; clear; done
# end
