#!/bin/bash
nmcli connection delete andino-lte; nmcli connection add type gsm ifname '*' con-name andino-lte apn "internet.mts.ru"; nmcli con up id andino-lte
