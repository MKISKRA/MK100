#!/bin/bash
#set -o nounset
#set -o errexit
echo 0 > /sys/class/leds/charger_board_led_red/brightness
sleep 0.2
echo 1 > /sys/class/leds/charger_board_led_red/brightness
sleep 0.2
echo 0 > /sys/class/leds/charger_board_led_red/brightness
sleep 0.2
echo 1 > /sys/class/leds/charger_board_led_red/brightness
sleep 0.2
echo 0 > /sys/class/leds/charger_board_led_red/brightness
# end
