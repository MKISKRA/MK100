#!/bin/bash
#LD_LIBRARY_PATH=/root/mk100/mk100t/ DISPLAY=:0  /root/mk100/mk100t/MK100T --platform wayland
#LD_LIBRARY_PATH=/root/mk100/mk100t/ /root/mk100/mk100t/MK100T --platform wayland
#LD_LIBRARY_PATH=/root/mk100/mk100t/ DISPLAY=:0  /root/mk100/mk100t/MK100T
sleep 5 && XDG_RUNTIME_DIR=/run/user/0 LD_LIBRARY_PATH=/root/mk100/mk100t/  /root/mk100/mk100t/MK100T --platform wayland
