#!/bin/sh
#export DISPLAY=:0.0
xset s off
xset s noblank
xset -dpms
#xset dpms 0 0 0
#xset -dpms
