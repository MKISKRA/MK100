#!/bin/bash
exit
LOG_FILE=$(date +"%d_%m_%Y")_stopModem.log
LOG_FILE_PATH=/root/mk100/mk100t/logs/$LOG_FILE
exec > >(while read -r line; do printf '%s %s\n' "$(date --rfc-3339=seconds)" "$line" | tee -a $LOG_FILE_PATH; done)
exec 2> >(while read -r line; do printf '%s %s\n' "$(date --rfc-3339=seconds)" "$line" | tee -a $LOG_FILE_PATH; done >&2)
# off минимизировать работу модема
if [ -e "/dev/ttyUSB2" ]; then
  echo "ttyUSB2 exists"
else
  echo "ttyUSB2 does not exist"
  exit 1
fi
/root/mk100/mk100t/redled.sh
current_date_time="`date "+%Y-%m-%d %H:%M:%S"`";
echo $current_date_time;
#nmcli con down id andino-lte
#mmcli -m any --command=AT+QCFG="nwscanseq",0
#mmcli -m any --command=AT+QCFG="nwscanmode",0 
#mmcli -m any --command=AT+CREG=0
#mmcli -m any --command=AT+QSCLK=0
mmcli -m any --command=AT+CFUN=4
for i in {1..16}
do
    echo "Modem i $i "
    string_signal="$(mmcli -m any --command=AT+CSQ)"
    echo $string_signal
    if [[ $string_signal == *"+CSQ: 99,99"* ]]; then
        echo "Signal 0 (Zero)"
	for ii in {1..5}
	do
	    echo "Modem ii $ii "
	    string_signal="$(mmcli -m any --command=AT+CSQ)"
            if [[ $string_signal != *"+CSQ: 99,99"* ]]; then
            	ii=99
                break
            fi
            sleep 0.2
	done
	if [ "$ii" -eq "5" ]; then
            echo "Signal 0 (Zero)";
            exit 1;
        fi
    fi
sleep 0.5
done
#sleep 5
#nmcli con down id andino-lte
#clear
current_date_time="`date "+%Y-%m-%d %H:%M:%S"`";
echo $current_date_time;

