#!/bin/sh
cp /root/mk100/mk100t/update/am/am_firmware.bin /root/mk100/mk100t/update/am/am_v2/XC8_Charger.hex
cd /root/mk100/mk100t/update/am/am_v2
chmod a+x avrdude burn_atiny.sh
./burn_atiny.sh
#Wait SUCCESS, ~350 seconds
