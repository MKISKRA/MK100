#!/bin/sh

### burn stm8 in "accumulatornii modul"

cd /root/mk100/mk100t/update/am/am_v4
echo 1 > /sys/class/leds/charger_board_ena_b/brightness
echo 495 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio495/direction
echo 1 > /sys/class/gpio/gpio495/value


STM8WD_SERIALDEV=/dev/ttyS5 STM8WD_DEBUG=0 STM8WD_FWSREC=/root/mk100/mk100t/update/am/am_firmware.bin STM8WD_FORCEUPDATE=true  ${d}./stm8wd
