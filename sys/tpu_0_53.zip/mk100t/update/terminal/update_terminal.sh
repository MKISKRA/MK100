#!/bin/bash
echo "----------------------------";
sleep 1;
cd /root/mk100/mk100t/update/terminal/;
unzip -o /root/mk100/mk100t/update/terminal/terminal_firmware.bin;
sleep 1;
chmod +x /root/mk100/mk100t/update/terminal/files/update_terminal_run.sh;
/root/mk100/mk100t/update/terminal/files/update_terminal_run.sh;
