#!/bin/bash
sleep 5;
AZIMUTH_INI_PATH=/root/mk100/mk100t/settings_azmtqt.ini LD_LIBRARY_PATH=/root/mk100/mk100t/ DISPLAY=:0  /root/mk100/mk100t/tpu_mk100; #--platform xcb

