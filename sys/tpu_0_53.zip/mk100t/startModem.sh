#!/bin/bash
exit
LOG_FILE=$(date +"%d_%m_%Y")_startModem.log
LOG_FILE_PATH=/root/mk100/mk100t/logs/$LOG_FILE
exec > >(while read -r line; do printf '%s %s\n' "$(date --rfc-3339=seconds)" "$line" | tee -a $LOG_FILE_PATH; done)
exec 2> >(while read -r line; do printf '%s %s\n' "$(date --rfc-3339=seconds)" "$line" | tee -a $LOG_FILE_PATH; done >&2)
if [ -e "/dev/ttyUSB2" ]; then
  echo "ttyUSB2 exists"
else
  echo "ttyUSB2 does not exist"
  exit 1
fi
if [ -e "/root/mk100/mk100t/modemairmode" ]; then
  echo "modemairmode exists"
  exit 1
else
  echo "modemairmode does not exist"
fi
/root/mk100/mk100t/greenled.sh
# on включит все функции модема
current_date_time="`date "+%Y-%m-%d %H:%M:%S"`";
echo $current_date_time;
#mmcli -m any --command=AT+CREG=1
#mmcli -m any --command=AT+QSCLK=1
mmcli -m any --command=AT+CFUN=1
#mmcli -m any --command=AT+QCFG="nwscanseq",0
#mmcli -m any --command=AT+QCFG="nwscanmode",0
#sleep 2
#nmcli con up id andino-lte
#clear
current_date_time="`date "+%Y-%m-%d %H:%M:%S"`";
echo $current_date_time;
