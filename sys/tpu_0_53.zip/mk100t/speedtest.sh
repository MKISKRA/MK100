#!/bin/bash
#apt install speedtest-cli
speedtest ; sleep 5
