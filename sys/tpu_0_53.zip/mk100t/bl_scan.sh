#!/bin/bash
hcitool -i hci0 lescan
