#!/bin/bash
ping -c 20 -v 8.8.8.8
