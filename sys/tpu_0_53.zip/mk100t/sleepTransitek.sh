#!/bin/sh
sleep 20 && pkill python3
