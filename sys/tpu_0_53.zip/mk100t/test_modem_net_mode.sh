#!/bin/bash
while :
do
#/root/mk100/mk100t/test_modem_net_mode_2.sh &
# Automatic (LTE/WCDMA/GSM)
echo "Automatic"
mmcli -m any --command=AT+QCFG="nwscanmode",0
mmcli -m any --command=AT+CFUN=1
sleep 10
#/root/mk100/mk100t/test_modem_net_mode_2.sh &
mmcli -m any --command=AT+CFUN=1
sleep 10
# GSM only
#echo "GSM"
#mmcli -m any --command=AT+QCFG="nwscanmode",1
#sleep 30
#/root/mk100/mk100t/test_modem_net_mode_2.sh &
# WCDMA only
#echo "WCDMA"
#mmcli -m any --command=AT+QCFG="nwscanmode",2
#sleep 30
#/root/mk100/mk100t/test_modem_net_mode_2.sh &
# LTE only
#echo "LTE"
#mmcli -m any --command=AT+QCFG="nwscanmode",3
#sleep 30
clear
#/root/mk100/mk100t/test_modem_net_mode_2.sh &
done

