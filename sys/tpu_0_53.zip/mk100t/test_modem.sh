#!/bin/bash
while :
do
  wget https://ftp.psn.ru/debian-cd/current/amd64/iso-cd/debian-12.10.0-amd64-netinst.iso
  echo "wget netinst"
  sleep 1
done
